RAINBOW MUSIC NOTES - transparent PNG frames (RGBA)
176x288 native, exported 2x = 352x576. 64 frames, seamless loop.
Notes pop in from nothing at varied depths, spread across the canvas, rise, then balloon-pop into confetti.
