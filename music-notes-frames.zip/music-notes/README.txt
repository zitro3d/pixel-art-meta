RAINBOW MUSIC NOTES - transparent PNG frames (RGBA)
128x128 native, exported 2x = 256x256. 64 frames, seamless loop (~15fps).
Notes float up, fade in/out, colour-cycle through the rainbow.
Composite directly (true alpha) or over any scene.
