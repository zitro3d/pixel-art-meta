RAINBOW MUSIC NOTES - transparent PNG frames (RGBA)
112x192 native, exported 2x = 224x384. 64 frames, seamless loop.
Notes pop in from nothing at varied depths/sizes, rise, then balloon-pop into confetti.
