RAINBOW MUSIC NOTES - transparent PNG frames (RGBA)
112x192 native, exported 2x = 224x384. 64 frames, seamless loop.
Notes burst on, glide up on a random drift, rainbow-cycle, then pop off like a bubble.
