RAINBOW MUSIC WAVES - transparent PNG frames (RGBA)
208x112 native, exported 2x = 416x224. 64 frames, seamless loop.
Glowing twin rainbow waveform lines pulsing to a 4-beat rhythm.
Composite with Screen/Add over any scene, or use the alpha directly.
