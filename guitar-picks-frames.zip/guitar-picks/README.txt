GUITAR PICKS - transparent PNG frames (RGBA)
192x240 native, exported 2x = 384x480. 64 frames, seamless loop.
Picks pop in, tumble upward and flip in 3D (front bright / back dark / edge-on sliver), then fade out.
