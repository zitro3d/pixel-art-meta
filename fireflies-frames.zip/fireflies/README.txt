FIREFLIES / GLOW MOTES - transparent PNG frames (RGBA)
224x148 native, exported 2x = 448x296. 72 frames, seamless loop (slow).
Warm glowing motes drift and softly blink. Composite with Screen/Add over any scene.
